Vtiger_Edit_Js("PatientCard_Edit_Js", {}, {
    hideField : function () {
        //Получение Формы
        var editViewForm = this.getForm();
        //Получение выбранного значения 
        var category = editViewForm.find('[name="eye_color"] option:selected').text();
        editViewForm.find('table').show();
        if (category == "Карие"){
            //Скрытие блока “Описание”
            editViewForm.find('table:contains(' + "Характеристика" + ')').hide();
        } else {
            //Отображение блока “Описание”
            editViewForm.find('table:contains(' + "Характеристика" + ')').show();
        }
    },
       
    registerHideField : function () {
         var editViewForm = this.getForm();
         var thisInstance = this;
         thisInstance.hideField();
         //Если значение поля Статус изменено, то вызывается метод “hideField()”
         editViewForm.find('[name="eye_color"]').on('change', function (e) {
              thisInstance.hideField();
         });
    },
       
    registerEvents: function () {
        this._super();
        this.registerHideField();
    }
});