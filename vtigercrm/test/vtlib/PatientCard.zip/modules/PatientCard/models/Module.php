 <?php
     class PatientCard_Module_Model extends Vtiger_Module_Model {
      
         public function isQuickCreateSupported() {
             return false;
         }
     }
 ?>