<?php

$languageStrings = array(
    'PatientCard' => 'Карточка пациентов',
    'Patient Card' => 'Карточка пациентов',
    'SINGLE_PatientCard' => 'Карточка пациентов',
    'LBL_ADD_RECORD' => 'Добавить запись в Карточку пациентов',
    'LBL_RECORDS_LIST' => 'Список записей в Карточке пациентов',
    'LBL_PATIENTCARD_INFORMATION' => 'Общая информация',
    'LBL_PATIENTCARD_CHARACTERRISTIC' => 'Характеристика',
    'Name of the organization' => 'Название организации',
    'Surname' => 'Фамилия',
    'Growth' => 'Рост',
    'Weight' => 'Вес',
    'Eye color' => 'Цвет глаз',
    'Registration date' => 'Дата регистрации',
    'Responsible' => 'Ответственный',
    'Characteristic' => 'Характеристика',
    'PatientCard' => 'Карточка пациентов',
    'Patient Card' => 'Карточка пациентов',
    'LBL_RESPONSIBLE' => 'Ответственный',
    'LBL_COUNT' => 'Количество',
);

// Начать исправление
include 'renamed/PatientCard.php';
